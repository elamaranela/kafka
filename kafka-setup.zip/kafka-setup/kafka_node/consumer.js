var kafka = require('kafka-node');
exports.consumer = function (req, res, next) {
 
  var HighLevelConsumer = kafka.Consumer;
  var Client = kafka.KafkaClient;
  var client = new Client('localhost:9092');
  var topics = [{
    topic: 'node-test02',
    partition: 0,
    time: -1,
  }];
var data='';
  var options = {
    autoCommit: false,
    fetchMaxWaitMs: 1000,
    fetchMaxBytes: 1024 * 1024,
  };

  var consumer = new HighLevelConsumer(client, topics, options);
  consumer.on("ready", function(message) {
    console.log("I am ready");
});
var offset = new kafka.Offset(client);
  var latestOffset =0
  offset.fetch(topics,  function (err, data) {
   
     latestOffset = data['node-test02']['0'];
  });
 
 
     consumer.on('message', function (message) {
      console.log(latestOffset['0']);
      console.log("Consumer current message: ", message);
     
        console.log("message.offset", message.offset);
        console.log("message.offset", (latestOffset['0']-1));
      if (message.offset == (latestOffset['0']-1)) {

        data = JSON.parse(message.value);
        res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(data.message, null, 3));
        console.log('from consumer',data);
        consumer.close(function(){});
      
      }
    
    })
    
    console.log('data out side',data)



  consumer.on('error', function (err) {
    console.log('error', err);
  });

  process.on('SIGINT', function () {
    consumer.close(true, function () {
      process.exit();
    });
  })
};

