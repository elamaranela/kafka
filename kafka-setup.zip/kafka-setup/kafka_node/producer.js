


exports.producer = function (req, res) {
   const message = req.body
var kafka = require('kafka-node');
var HighLevelProducer = kafka.HighLevelProducer;
var KeyedMessage = kafka.KeyedMessage;
var Client = kafka.KafkaClient;
var client = new Client('localhost:9092', 'my-client-id', {
    sessionTimeout: 300,
    spinDelay: 100,
    retries: 2
  });
  
  client.on('error', function(error) {
    console.error(error);
  });

  var producer = new HighLevelProducer(client);
 
producer.on('ready', function() {
//   var messageBuffer = type.toBuffer({
//     enumField: 'sym2',
//     id: '3e0c63c4-956a-4378-8a6d-2de636d191de',
//     timestamp: Date.now()


const buf1 = Buffer.allocUnsafe(100);
  const messageBuffer = JSON.stringify({
    message}
  );

  var payload = [{
    topic: 'node-test02',
    messages: messageBuffer,
    attributes: 1 
  }];

  producer.send(payload, function(error, result) {
    console.info('Sent payload to Kafka: ', payload);
    if (error) {
      console.error(error);
    } else {
      var formattedResult = result[0];
      console.log('result: ', result)
      res.json(result);
res.send();
    }
  });
});

producer.on('error', function(error) {
  console.error(error);
})};